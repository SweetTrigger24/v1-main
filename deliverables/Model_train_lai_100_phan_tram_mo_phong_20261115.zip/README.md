# Mô hình hiện tại train lại trên PC

Huấn luyện bằng data/training_data.sqlite3 và --skip-csv-import --include-weather-samples: 86.041 mẫu weather_sample, 100% mô phỏng, 0 số đo DHT22 thật. Bộ train đã loại 1.800 mẫu dùng forecast hoặc chưa xảy ra khi tải nguồn. Không sao chép thêm bộ dữ liệu vào thư mục kết quả.

Giới hạn 120 epoch, dừng sau 70 epoch, seed 42, EarlyStopping patience=8, khôi phục trọng số tốt nhất. Cửa sổ train/validation/test: [1936, 407, 407]. Chia theo thời gian 70/15/15; min-max chỉ tính trên train.

| Đánh giá | Nhiệt độ RMSE °C | Độ ẩm RMSE điểm %RH |
|---|---:|---:|
| Validation LSTM | 1.2576 | 7.3101 |
| Validation đối chứng | 1.4536 | 8.0656 |
| Test LSTM | 3.4655 | 15.3037 |
| Test đối chứng | 6.2560 | 10.9196 |

use_lstm=True, được quyết định bằng validation trên cả hai biến. Không thay quyết định dựa vào tập test. Kết quả trên mô phỏng không phải độ chính xác đã đo trên cảm biến thật.

Cặp forecast_12h.keras và forecast_12h.json đã thay trong model/ trên PC, hash khớp. previous_model/ giữ cặp trước đó. verification.json xác nhận nạp mô hình, 17.232 tham số, tái tính khớp validation/test và xuất đủ 72 mốc. Pi chưa được kết nối hay cập nhật trong lần train này.

run.json ghi lệnh và hash dữ liệu; training.log ghi toàn bộ quá trình. Không đổi kiến trúc 144×4 → LSTM48 → Dropout0,15 → Dense144 → 72×2.

## Rút gọn cột sau huấn luyện

CSV hiện rút còn time,temp,hum,label. Các giá trị time/temp/hum và dữ liệu SQLite dùng để train không đổi; nguồn weather_sample vẫn có trong metadata và SQLite. run.json giữ hash CSV lúc train; data_format_change.json ghi hash trước/sau đổi định dạng và hash độc lập của các giá trị đặc trưng. Không huấn luyện lại hoặc thay trọng số trong lần chỉnh cột.
