# Mô hình train lại ngày 16/11/2026

Đọc đủ 87.841 dòng từ data/sensor_data.csv, chia theo thời gian 70/15/15. Nguồn vận hành theo nhãn người dùng: 73.441 weather_sample và 14.400 sensor. Đây là train ngoại tuyến với mốc cắt dữ liệu 16/11/2026 05:00; giờ train thực tế và số dòng có mốc sau giờ bắt đầu được lưu trong metadata.

Giữ LSTM một lớp 48 nút, cửa sổ 24 giờ (144 mốc), dự báo 12 giờ (72 mốc). Đã chạy 50 epoch, dùng early stopping với patience=8 và khôi phục trọng số tốt nhất. LSTM được chọn vì thắng baseline trên cả hai biến ở validation.

Validation RMSE nhiệt độ/độ ẩm: 1.2489 °C / 7.7585 %RH. Baseline: 1.4638 / 8.4180. Sai số là kết quả trên bộ dữ liệu hiện có, không phải kiểm định thu thập DHT22 mới.

Model/metadata phải chuyển cùng cặp. SHA-256 trọng số: db83324431c8d207463bfbda93adacf45794edbd2355b41354fb03469609d320. Đã cập nhật model/ trên PC, chưa chuyển Pi. Log và verification.json nằm cùng thư mục này.

## Phân loại hiện tại

Ngày 16/11, mở rộng nhãn sensor từ 10 lên 20 ngày cuối: 28.800 sensor và 59.041 weather_sample, theo nhãn do người dùng cấu hình. Các số lượng/nguồn trong run.json và kết quả train phía trên là thông tin lịch sử lúc train. Chỉ đổi nhãn CSV; time/temp/hum và chuỗi đầu vào 10 phút của bộ hai tháng giữ nguyên. Vì vậy không train lại trọng số; metadata mô hình thêm current_dataset_revision cho dữ liệu hiện tại. source_label_assignment.json ghi kiểm tra mới nhất. Chưa cập nhật Pi/GitHub cho lần đổi nhãn 20 ngày.
